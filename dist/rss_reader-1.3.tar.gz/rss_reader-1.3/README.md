RSS feeds reader README file.

useful information is available at docs/
    docs/task.md contains the requirements to this project
    docs/rss_sources.md  contains links to RSS feeds, which are used at time of developing the project

logs save at the user's home directory at directory rss_log/

files with parsed information save in .json format at the user's home directory at directory rss_data/

Installation

files for installation placed id directory dist/
better to install package at virtual environment
create any directory and come to the directory
run 'pip -m venv name_of_your_venv' to create virtual environment
run 'name_of_your_venv/Scripts/activate' to activate the virtual environment
run 'pip install correct_path_to/package_name' to install the package at virtual environment
run 'python -m rss_reader', 'rss_reader', 'rss-reader', or 'python -m rss-reader' to execute
use 'rss-reader --help' to get run options
