from .rss_reader import RssReaderClass, main

if __name__ == '__main__':
    main()
